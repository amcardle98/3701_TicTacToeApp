package tictactoe;

import java.util.Scanner;

public class TicTacToe {

    public static void main(String[] args) {
        new TicTacToe().start();
    }
    
    public void start(){
        Board board = new Board();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println("Please enter a character");
        board.addToInputs(scanner.nextLine().charAt(0));
        System.out.println(board.toString());
    }
    
}
