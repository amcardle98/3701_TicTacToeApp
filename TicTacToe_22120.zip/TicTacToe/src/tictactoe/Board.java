package tictactoe;

import java.util.ArrayList;
import java.util.List;

public class Board {
    private final List<Character> inputs = new ArrayList<Character>(9);
    
    public Board(){
        
    }
    
    public void addToInputs(Character input){
        inputs.add(input);
    }
    
    @Override
    public String toString(){
        String board = null;
        
        if(!inputs.isEmpty()){
           board = "_" + inputs.get(0) + "_|_" + inputs.get(1) + "_|_" + inputs.get(2) + "_\n" + 
                  "_" + inputs.get(3) + "_|_" + inputs.get(4) + "_|_" + inputs.get(5) + "_\n" +
                  "_" + inputs.get(6) + "_|_" + inputs.get(7) + "_|_" + inputs.get(8) + "_\n";
        } else {
            System.out.println("Not enough characters");
        }
        return board;
    }
}
