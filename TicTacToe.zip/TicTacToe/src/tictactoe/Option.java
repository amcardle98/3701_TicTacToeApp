package tictactoe;

public enum Option {
    X, O;
}
