package tictactoe;

import java.util.Scanner;

public class TicTacToe {
    
    Board board = new Board();
    Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        new TicTacToe().start();
    }
    
    public void start(){
        board.initializeBoard();
        
        System.out.println("Welcome to Tic Tac Toe!"); 
        
        Play();
    }
    
    public void checkWin(){
        if((board.getInputs(0, 0).equals("X") && board.getInputs(0, 1).equals("X") && board.getInputs(0, 2).equals("X")) || 
            board.getInputs(0, 0).equals("O") && board.getInputs(0, 1).equals("O") && board.getInputs(0, 2).equals("O")) { 
            
            System.out.println(board.getInputs(0, 0) + " wins");
            System.exit(0);
        }
        if((board.getInputs(1, 0).equals("X") && board.getInputs(1, 1).equals("X") && board.getInputs(1, 2).equals("X")) || 
            board.getInputs(1, 0).equals("O") && board.getInputs(1, 1).equals("O") && board.getInputs(1, 2).equals("O")) { 
            
            System.out.println(board.getInputs(1, 0) + " wins");
            System.exit(0);
        }
        if((board.getInputs(2, 0).equals("X") && board.getInputs(2, 1).equals("X") && board.getInputs(2, 2).equals("X")) || 
            board.getInputs(2, 0).equals("O") && board.getInputs(2, 1).equals("O") && board.getInputs(2, 2).equals("O")) { 
            
            System.out.println(board.getInputs(2, 0) + " wins");
            System.exit(0);
        }
        if((board.getInputs(0, 0).equals("X") && board.getInputs(1, 0).equals("X") && board.getInputs(2, 0).equals("X")) || 
            board.getInputs(0, 0).equals("O") && board.getInputs(1 ,0).equals("O") && board.getInputs(2, 0).equals("O")) { 
            
            System.out.println(board.getInputs(0, 0) + " wins");
            System.exit(0);
        }
        if((board.getInputs(0, 1).equals("X") && board.getInputs(1, 1).equals("X") && board.getInputs(2, 1).equals("X")) || 
            board.getInputs(0, 1).equals("O") && board.getInputs(1, 1).equals("O") && board.getInputs(2, 1).equals("O")) { 
            
            System.out.println(board.getInputs(0, 1) + " wins");
            System.exit(0);
        }
        if((board.getInputs(0, 2).equals("X") && board.getInputs(1, 2).equals("X") && board.getInputs(2, 2).equals("X")) || 
            board.getInputs(0, 2).equals("O") && board.getInputs(1, 2).equals("O") && board.getInputs(2, 2).equals("O")) { 
            
            System.out.println(board.getInputs(0, 2) + " wins");
            System.exit(0);
        }
        if((board.getInputs(0, 0).equals("X") && board.getInputs(1, 1).equals("X") && board.getInputs(2, 2).equals("X")) || 
            board.getInputs(0, 0).equals("O") && board.getInputs(1, 1).equals("O") && board.getInputs(2, 2).equals("O")) { 
            
            System.out.println(board.getInputs(0, 0) + " wins");
            System.exit(0);
        }
        if((board.getInputs(0, 2).equals("X") && board.getInputs(1, 1).equals("X") && board.getInputs(2, 0).equals("X")) || 
            board.getInputs(0, 2).equals("O") && board.getInputs(1, 1).equals("O") && board.getInputs(2, 0).equals("O")) { 
            
            System.out.println(board.getInputs(0, 2) + " wins");
            System.exit(0);
        }
    }
    
    public void Play(){
        String choice;
        Integer rowVal;
        Integer colVal;
        
        for(int i = 0; i < 10;i++){
            if(i % 2 == 0){
                choice = "X";
                System.out.println("Enter a row "); 
                    rowVal = scanner.nextInt()- 1;
                System.out.println("Enter a column");
                    colVal = scanner.nextInt() - 1;
                
                board.addToInputs(choice, rowVal, colVal);
                System.out.println(board.toString());
                
                System.out.println("-----------");
                System.out.println("Next player");
                System.out.println("-----------");
                
                checkWin();
                
            } else {
                choice = "O";
                System.out.println("Enter a row ");
                    rowVal = scanner.nextInt() - 1;
                System.out.println("Enter a column");
                    colVal = scanner.nextInt() - 1;
                
                board.addToInputs(choice, rowVal, colVal);
                System.out.println(board.toString());
                
                System.out.println("-----------");
                System.out.println("Next player");
                System.out.println("-----------");
                
                checkWin();
                
            }
        }
    }
}
