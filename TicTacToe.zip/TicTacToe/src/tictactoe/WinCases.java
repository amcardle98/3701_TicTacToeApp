package tictactoe;

public enum WinCases {
    
}
