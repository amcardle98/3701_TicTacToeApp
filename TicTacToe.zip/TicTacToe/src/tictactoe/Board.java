package tictactoe;

import java.util.ArrayList;
import java.util.List;

public class Board {
    private final Integer boardRows = 3;
    private final Integer boardCols = 3;
    
    private final String[][] inputs = new String[boardRows][boardCols];
    
    public Board(){
        
    }
    
    public void addToInputs(String choice, Integer rowInput, Integer colInput){
        if(inputs[rowInput][colInput] == " "){
            inputs[rowInput][colInput] = choice;
        } else {
            System.out.println("Someone already played there!");
        }
    }
    
    public void initializeBoard(){
        for(int i = 0;i < boardRows;i++){
            for(int j = 0;j < boardCols;j++){
                inputs[i][j] = " ";
            }
        }
    }
    
    @Override
    public String toString(){
        String board = "_" + inputs[0][0] + "_|_" + inputs[1][0] + "_|_" + inputs[2][0] + "_" +
                       "\n_" + inputs[0][1] + "_|_" + inputs[1][1] + "_|_" + inputs[2][1] + "_" +
                       "\n_" + inputs[0][2] + "_|_" + inputs[1][2] + "_|_" + inputs[2][2] + "_" ;
        
        return board;
    }
    
    public String getInputs(int i, int j){
        return inputs[i][j];
    }
}
